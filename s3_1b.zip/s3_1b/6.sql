WITH RECURSIVE date_range AS (
    SELECT
        MIN(sale_date)::date AS min_date,
        MAX(sale_date)::date AS max_date
    FROM public.flourmills_sales
),
calendar AS (
    SELECT min_date AS sale_date, max_date
    FROM date_range

    UNION ALL

    SELECT (sale_date + 1)::date, max_date
    FROM calendar
    WHERE sale_date < max_date
)
SELECT COUNT(*)
FROM calendar;