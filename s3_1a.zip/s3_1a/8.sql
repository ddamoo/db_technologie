CREATE OR REPLACE PROCEDURE get_customer_sales(p_customer_id VARCHAR(20))
LANGUAGE plpgsql
AS $$
DECLARE
    total_sales NUMERIC(10,2);
BEGIN
    SELECT COALESCE(SUM(sales), 0)
    INTO total_sales
    FROM orders
    WHERE customer_id = p_customer_id;

    RAISE NOTICE 'Customer ID: %, Total Sales: %', p_customer_id, total_sales;
END;
$$;

SELECT customer_id, SUM(sales) AS total_sales
FROM public.orders
WHERE customer_id = 'CUST00001'
GROUP BY customer_id;

SELECT customer_id, sales
FROM orders
WHERE customer_id = 'C001';