SELECT o.order_id, o.sales, c.customer_name FROM orders o INNER JOIN customers c ON o.customer_id = c.customer_id WHERE o.sales > 500 ORDER BY o.sales DESC;
